/*jshint unused:true*/

//declare a greeting function
function sayGreeting(greetins) {
   alert(greetins);
    console.log(greetins);
    return greetins;    
}

//create a variable greets
var greets = 'hello worlds!';

//call func greetings
sayGreeting(greets);
