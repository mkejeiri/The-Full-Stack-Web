var gulp = require ('gulp');
var uglify = require ('gulp-uglify');
var sass = require ('gulp-sass');
var jshint = require ('gulp-jshint');
var webserver = require('gulp-webserver');



//test task
gulp.task('Test', function () {
    console.log("Test gulp testing ran");    
});

//Minify JS
gulp.task('minifyjs',function () {
    return gulp.src('src/*.js')    
        .pipe(uglify())
        .pipe(gulp.dest('app/js/'));    
})

//Compile sass
gulp.task('scss', function () {
    return gulp.src('scss/*.scss')
                .pipe(sass())
                .pipe(gulp.dest('app/css/'));
})

//JSHint

gulp.task('hint', function () {
    return gulp.src('src/*.js')
                .pipe(jshint())
                .pipe(jshint.reporter('default'));//diff reporters exist (customs)    
});


//Webserver
gulp.task('webserver', function () {
    return gulp.src('app')
                .pipe(webserver({
                    port:8000,
                    livereload:true,
                    open:true
                }));    
});


gulp.task('default',['minifyjs','scss','hint','webserver']);