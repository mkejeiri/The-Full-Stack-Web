var mongoose = require('mongoose');


//Movie Schema:
//  Mongo is schemeless: at database level you don't have to create ur schema
//  With mongoose we will set it at apps level
var MovieSchema = mongoose.Schema({
    title: {
        type: String
    }, 
    plot : {
        type: String
    },
    cover:{
        type:String
    },
    genre:{
        type: String
    },
    actors:{
        type: Array 
    },
    relaseDate:{ 
        type: Date
    }
    });

var Movie = module.exports = mongoose.model('Movie',MovieSchema); //to have access to the 'Movie' object outside this file

//we create 'getMovies' method and export it to be accessble outside this file
module.exports.getMovies = function (callback, limit) {
    Movie.find(callback).limit(limit); 
}
 
module.exports.getMoviesById = function (id, callback) {
    Movie.findById(id,callback); 
}