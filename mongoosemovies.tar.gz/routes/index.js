
//import all the following:
var express = require('express');
var router = express.Router();//built-in middleware function in Express. It parses incoming requests with urlencoded payloads and is based on body-parser

router.get('/',function (req, res, next) {
    res.send('INDEX: NOT YET IMPLEMENTED');    
});

module.exports = router; //to be accessible outside this file. 

