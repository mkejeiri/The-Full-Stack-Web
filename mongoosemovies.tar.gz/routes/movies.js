//import all the following:
var express = require('express');
var router = express.Router();//built-in middleware function in Express. It parses incoming requests with urlencoded payloads and is based on body-parser

//Bring in the 'Movie' Model
var Movie = require('../models/Movie');

//List all movies
router.get('/',function (req, res, next) {
    Movie.getMovies(function (err, movies) {
      if (err) {
          res.send(err);
      }
      res.json(movies); 
    },10);    
});

//Get a single Movie
router.get('/:id',function (req, res, next) {
 Movie.getMoviesById([req.params.id], function (err, movie) {
     if (err) {
         res.send(err);
    }
    res.json(movie);
 });   
})


//Add a movie (post.request)
//Normally we should get the data from a form
//but we will create a data locally and add store it into the database
router.post('/', function (req, res, next) {
    var movie = req.body;
    // var newMovie = new Movie({
    //     "title" : "Submergence",
    //     "description": "In a room with no windows on the eastern coast of Africa, an Englishman, James More, is held captive by jihadist fighters. Thousands of miles away in the Greenland Sea, Danielle Flinders",
    //     "cover":"https://images-na.ssl-images-amazon.com/images/M/MV5BMjEyNTQyNzY3NF5BMl5BanBnXkFtZTgwODcxMzY1NDM@._V1_UX182_CR0,0,182,268_AL_.jpg",
    //     "genre" :"Thriller",
    //     "releaseDate":new Date('2018-04-13'),
    //     "actors":["James McAvoy","Alicia Vikander","Alexander Siddig"]       
    // });
    var newMovie = new Movie(movie);
    newMovie.save(function (err, movie) {
       if (err) {
           res.send(err); 
       }
       res.json(movie);
    });
});

//update movie
router.put('/:id',function (req,res,next ) {
    // var updatedMovie =Movie.getMoviesById([req.params.id]);
    var query = {_id :[req.params.id] };
    var body = req.body;
    Movie.update(query,{$set:body},{/*Options : we don't have any!*/}, function (err,movie ) {
        if (err) {
            res.send(err);
        }
        res.json(movie);        
    });

    
})

//delete movie
router.delete('/:id',function (req,res,next ) {
    var query = {_id :[req.params.id]};
    Movie.remove(query, function (err) {
        if (err) {
            res.send(err);
        }
        res.json({ "msg":"success"});        
    });    
})  

 


module.exports = router; //to be accessible outside this file. 

