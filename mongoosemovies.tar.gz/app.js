var express = require ('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');

const options = {
    useMongoClient: true,
    autoIndex: false, // Don't build indexes
    reconnectTries: Number.MAX_VALUE, // Never stop trying to reconnect
    reconnectInterval: 500, // Reconnect every 500ms
    poolSize: 10, // Maintain up to 10 socket connections
    // If not connected, return errors immediately rather than waiting for reconnect
    bufferMaxEntries: 0
  };
//connect 
//function connect(uris: string, options: ConnectionOptions, callback: (err: mongodb.MongoError) => void): null;
var uri = 'mongodb://localhost/mongomovies';
mongoose.connect(uri,options);


/** The default connection of the mongoose module. */
var db = mongoose.connection;

//Check for errors after connection
db.on('error',console.error.bind(console,'db connection Error:'));
db.once('open', function () {
    console.log('mongodb connected');
});


//requires the routes from routes folder(files)
var route_index = require ('./routes/index');
var route_movies = require('./routes/movies');




//init express framework
var app = express();

app.use(bodyParser.json());

//set home to index routes
app.use('/',route_index);

//set the api which should goes to movies as follows:
app.use('/api/v1/movies', route_movies);


//run the server on port : 3000
var port = 3000;
app.listen(port, function(){
    console.log('server running on port: '+port);
});

