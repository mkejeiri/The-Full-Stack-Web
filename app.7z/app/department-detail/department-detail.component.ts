/**
 * department-detail.component.ts
 */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router, ParamMap} from '@angular/router';
import { parse } from 'querystring';
import { ADDRGETNETWORKPARAMS } from 'dns';

@Component({
  selector: 'app-department-detail',
  template: `
    <h3>
      department with id = {{departmentId}}
    </h3>
    <br><br><br>
    <a (click)="previousElement(departmentId)">Previous</a>
    <a (click)="nextElement(departmentId)">Next</a>


  `,
  styles: []
})
export class DepartmentDetailComponent implements OnInit {
  public departmentId:number;
  constructor(private route:ActivatedRoute, private routerNavigate:Router) { }

  ngOnInit() {
    //get the parameter id from url

    /*
    * snapshot.paramMap get called only once through ngOnInit and didn't refresh the template we next to subscribe to 
    * an observable
    */

    //this.departmentId = parseInt(this.route.snapshot.paramMap.get('id'));

    //We subscribe to an observable ParamMap to watch the value id.
    this.route.paramMap
    .subscribe((params:ParamMap) => this.departmentId = parseInt(params.get('id')));

  }

  previousElement(departmentId){
    let id = this.departmentId-1;
    this.routerNavigate.navigate(['/departments/',id]);
  }

  nextElement(departmentId){
    let id = this.departmentId+1;
    console.log(id);
    this.routerNavigate.navigate(['/departments/',id]);
  }
}
