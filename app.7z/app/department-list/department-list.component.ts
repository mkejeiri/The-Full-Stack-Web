/**
 *  department-list.component.ts
 */
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-department-list',
  template: `
    <p>
      Department list
    </p>
    <ul>
    <li *ngFor="let department of departments" (click)="OnSelect(department)"><span>{{department.id}}</span> {{department.name}}</li>
    </ul>
  `,
  styles: []
})
export class DepartmentListComponent implements OnInit {
constructor(private _router:Router) { }

  OnSelect(department){
    this._router.navigate(['/departments', department.id]);
  }
  ngOnInit() {
  }

  //Dummy data.
  public departments = [
    {id:1, name:"Angular"},
    {id:2, name:"Node"},
    {id:3, name:"Mongo"},
    {id:4, name:"bootstrap"} 
] ;

}
