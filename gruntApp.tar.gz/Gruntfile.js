module.exports = function (grunt) {
    //  //test the grunt
    // grunt.registerTask('test', function (){        
    //    console.log('Test task Ran...');
    // });
 
    //with grunt you need to use a config
    grunt.initConfig({
        concat: {
            js:{
                src:['src/js/first.js','src/js/second.js','src/js/third.js'],
                dest: 'dist/js/app.bundle.js'
            },
            css:{
                src:['src/css/first.css','src/css/second.css','src/css/third.css'],
                dest: 'dist/css/app.bundle.css'
            }  
        },
        //watch mode: any change in *.js or *.css, the concat is called... 
        watch:{
            js: {
                files : ['src/js/*.js'],
                tasks:['concat']
            },
            css: {
                files :['src/css/*.css'],
                tasks:['concat']
            }
        }
    });
   
    //grunt.registerTask('default', ['concat']); //run grunt without specifying the task
    grunt.registerTask('default', ['watch']); //the default will be watch
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-watch');

}